<?php
echo "<h1>Hello from Elastic Beanstalk</h1>";
?>